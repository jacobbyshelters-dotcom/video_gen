#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
mkdir -p "$ROOT/renders"
cd "$ROOT/remotion"
for n in $(seq -w 1 12); do
  ID="episode-$n"
  echo "Rendering $ID..."
  npx remotion render src/index.ts "$ID" "$ROOT/renders/$ID.mp4" --codec=h264
done
echo "All episodes rendered into $ROOT/renders/"
