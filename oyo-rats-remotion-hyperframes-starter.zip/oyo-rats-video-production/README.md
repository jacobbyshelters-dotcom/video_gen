# Oyo Rats Campaign — Remotion + Hyperframes production starter

**Target:** 12 separate videos × 120 seconds each (24 minutes total), vertical 1080×1920, 24 fps, MP4/H.264.  
**Style:** comedic, expressive rat characters with exaggerated movement; Ibadan/Oyo-inspired backgrounds.  
**Slogan:** “Continuity. Peace. Progress.”

## Important status and limits

This is a runnable **starter project**, not a completed 24-minute campaign render. The included rat artwork is procedural 2D vector/CSS animation used as a placeholder. It does not yet contain realistic generated 3D footage, recorded Yoruba voices, or a licensed music track. The dialogue in `scripts/episodes.json` is a newly structured adaptation from the available brief, not a verbatim recovery of the earlier full script. Have a fluent Yoruba speaker review spelling, tone marks, idiom, and delivery before publishing.

The Remotion compositions include 12 distinct 120-second timelines with animated characters, titles, location cards, Yoruba/English dialogue cards and the campaign slogan. The dialogue cues currently cycle through each episode; they are not a complete timed two-minute voice script. Replace placeholder visuals/audio with generated and recorded assets for a finished campaign.

## Requirements

- Node.js 22+
- FFmpeg available on PATH
- Internet access for npm dependencies
- A computer/Codespace with enough CPU/RAM to render 12 videos (each is 2,880 frames)

## Install in GitHub Codespaces (Linux)

From the project root:

```bash
chmod +x install.sh render-all.sh
./install.sh
```

If FFmpeg is missing:

```bash
sudo apt-get update
sudo apt-get install -y ffmpeg
```

## Preview and render with Remotion

```bash
cd remotion
npm run dev
```

Render one episode:

```bash
npx remotion render src/index.ts episode-01 ../renders/episode-01.mp4 --codec=h264
```

Render all 12 episodes from the project root:

```bash
./render-all.sh
```

Output files are written to `renders/episode-01.mp4` through `episode-12.mp4`. The renderer may take considerable time. The first render may download the Chromium/headless-shell browser.

## Hyperframes path

Hyperframes is the HTML-based composition workflow. From the project root:

```bash
cd hyperframes
npx hyperframes doctor
npx hyperframes preview
```

Render the included 120-second HTML demo:

```bash
npx hyperframes render --output ../renders/oyo-rats-hyperframes-demo.mp4 --fps 24 --quality standard
```

Generate 12 separate HTML drafts from the episode metadata:

```bash
node make-episodes.mjs
```

**Note:** The episode HTML files are drafts. Before batch-rendering them, open each file and make it the active root composition in the Hyperframes project, or use the generated HTML as the base for a proper project per episode. Remotion is the current batch-render path in this starter.

## Add generated footage and real audio

1. Generate short character clips in your chosen video generator, maintaining the same Tolu/Wale reference images and 9:16 framing.
2. Copy the rendered clips into `remotion/public/media/` and import them as `<OffthreadVideo>` or `<Video>` layers in `src/Video.tsx`.
3. Put Yoruba narration files in `remotion/public/audio/` and add `<Audio src={staticFile('audio/episode-01-yoruba.wav')} />` at the matching sequence positions.
4. Add a licensed/royalty-free music bed and sound effects; duck music under speech.
5. Review every subtitle with a fluent Yoruba speaker, confirm the subtitle timing, then render and watch the full MP4.
6. Verify the final files with `ffprobe`.

## Verify MP4 outputs

```bash
ffprobe -v error -show_entries format=duration:stream=codec_name,width,height,r_frame_rate   -of default=noprint_wrappers=1 renders/episode-01.mp4
```

Expected video stream: 1080 × 1920, 24/1 fps, H.264; duration around 120 seconds.

## Project structure

- `scripts/episodes.json` — 12 episode briefs, beats, Yoruba dialogue cues and English subtitle translations.
- `remotion/src/` — Remotion video renderer and 12 composition registrations.
- `hyperframes/index.html` — HTML/CSS animated proof-of-concept composition.
- `hyperframes/episodes/` — output location for episode HTML drafts.
- `render-all.sh` — batch MP4 export.
