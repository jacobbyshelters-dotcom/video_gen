#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
command -v node >/dev/null || { echo "Install Node.js 22+ first"; exit 1; }
node -e "if (+process.versions.node.split('.')[0] < 22) process.exit(1)" || { echo "Node.js 22+ required"; exit 1; }
command -v ffmpeg >/dev/null || { echo "Install FFmpeg first: sudo apt-get update && sudo apt-get install -y ffmpeg"; exit 1; }
echo "Installing Remotion dependencies..."
(cd "$ROOT/remotion" && npm install)
echo "Installing Hyperframes dependencies..."
(cd "$ROOT/hyperframes" && npm install)
echo "Installation complete. Run ./render-all.sh to render all 12 Remotion episodes."
