import React from 'react';
import {Composition} from 'remotion';
import {episodes} from './episodes';
import {EpisodeVideo} from './Video';

export const FPS = 24;
export const DURATION_SECONDS = 120;
export const OyoRatsRoot: React.FC = () => (
  <>
    {episodes.map((episode) => (
      <Composition
        key={episode.id}
        id={episode.id}
        component={EpisodeVideo}
        durationInFrames={FPS * DURATION_SECONDS}
        fps={FPS}
        width={1080}
        height={1920}
        defaultProps={{episode}}
      />
    ))}
  </>
);
