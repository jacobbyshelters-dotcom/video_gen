import React from 'react';
import {AbsoluteFill, Audio, Sequence, staticFile, useCurrentFrame, useVideoConfig, interpolate, spring} from 'remotion';
import type {Episode} from './episodes';

const bg = ['#c56d32','#bd7542','#d69a54','#7c925d','#c88a47','#9b785b'];

const Rat: React.FC<{kind:'tolu'|'wale'; frame:number; x:number}> = ({kind, frame, x}) => {
  const hop = Math.abs(Math.sin(frame / 8)) * 42;
  const lean = Math.sin(frame / 13) * 9;
  const fur = kind === 'tolu' ? '#8b7465' : '#514c4c';
  const accessory = kind === 'tolu' ? '#2c8a4b' : '#b52635';
  return <div style={{position:'absolute',left:`${x}%`,bottom:260+hop,transform:`translateX(-50%) rotate(${lean}deg)`,width:330,height:420,filter:'drop-shadow(0 20px 12px #24180c55)'}}>
    <svg viewBox="0 0 330 420" width="100%" height="100%">
      <path d={`M175 290 Q${205+Math.sin(frame/9)*28} 350 285 360 Q325 365 308 345`} fill="none" stroke={fur} strokeWidth="13" strokeLinecap="round"/>
      <ellipse cx="160" cy="290" rx="94" ry="115" fill={fur}/>
      <ellipse cx="155" cy="326" rx="57" ry="70" fill="#d8b8a1"/>
      <path d={`M105 375 L${75+Math.sin(frame/5)*13} 400 M200 375 L${230-Math.sin(frame/5)*13} 400`} stroke={fur} strokeWidth="22" strokeLinecap="round"/>
      <circle cx="110" cy="118" r="48" fill={fur}/><circle cx="219" cy="118" r="48" fill={fur}/>
      <circle cx="110" cy="118" r="26" fill="#e5a6a0"/><circle cx="219" cy="118" r="26" fill="#e5a6a0"/>
      <ellipse cx="165" cy="175" rx="91" ry="82" fill={fur}/>
      <ellipse cx="167" cy="202" rx="57" ry="42" fill="#c9a998"/>
      <ellipse cx="166" cy="184" rx="18" ry="13" fill="#d96e72"/>
      <ellipse cx="137" cy="157" rx="11" ry="15" fill="#fff"/><ellipse cx="194" cy="157" rx="11" ry="15" fill="#fff"/>
      <circle cx={139+Math.sin(frame/10)*2} cy="159" r="5" fill="#171717"/><circle cx={196+Math.sin(frame/10)*2} cy="159" r="5" fill="#171717"/>
      <path d={`M140 215 Q166 ${226+Math.sin(frame/4)*7} 194 214`} fill="none" stroke="#4a2525" strokeWidth="5" strokeLinecap="round"/>
      <path d="M125 206 L75 196 M124 217 L69 222 M205 206 L255 196 M205 217 L262 224" stroke="#f3e2d7" strokeWidth="3" strokeLinecap="round"/>
      <path d="M88 109 Q162 35 242 109 L235 125 Q162 90 95 125Z" fill={accessory}/>
      {kind==='tolu' ? <path d="M130 93 Q165 70 205 93 L202 108 L132 108Z" fill={accessory}/> : <path d="M98 133 Q160 151 229 128 L224 147 Q164 169 104 150Z" fill={accessory}/>}
      <path d="M220 285 L246 313" stroke="#d8b45d" strokeWidth="10" strokeLinecap="round"/>
      <circle cx="245" cy="315" r="10" fill="#d8b45d"/>
    </svg>
    <div style={{position:'absolute',bottom:-30,left:0,right:0,textAlign:'center',fontSize:25,fontWeight:900,color:'white',textShadow:'0 2px 5px #000'}}>{kind==='tolu'?'TOLU':'WALE'}</div>
  </div>;
};

export const EpisodeVideo: React.FC<{episode:Episode}> = ({episode}) => {
  const frame = useCurrentFrame();
  const {fps,durationInFrames} = useVideoConfig();
  const beatFrames = Math.floor(durationInFrames / episode.beats.length);
  const beatIndex = Math.min(episode.beats.length-1, Math.floor(frame/beatFrames));
  const beat = episode.beats[beatIndex];
  const local = frame % beatFrames;
  const fade = interpolate(local,[0,12,beatFrames-12,beatFrames],[0,1,1,0.94],{extrapolateRight:'clamp'});
  const slide = spring({frame:local,fps,config:{damping:12}});
  const lineIndex = Math.min(episode.yoruba.length-1, Math.floor(frame/(durationInFrames/episode.yoruba.length)));
  const dialogue = episode.yoruba[lineIndex];
  const bgColor = bg[Number(episode.id.slice(-2))-1] || '#a56f4c';
  const titleOpacity = interpolate(frame,[0,30,90],[1,1,0],{extrapolateRight:'clamp'});
  return <AbsoluteFill style={{background:bgColor,fontFamily:'Arial, sans-serif',overflow:'hidden'}}>
    <AbsoluteFill style={{background:'linear-gradient(180deg,#f5c77b 0%,#e9a15d 40%,#4d5942 100%)'}}/>
    <div style={{position:'absolute',top:0,left:0,right:0,height:660,background:'linear-gradient(180deg,#fff2c9aa,#fff0 80%)'}}/>
    {Array.from({length:8},(_,i)=><div key={i} style={{position:'absolute',bottom:310+(i%3)*50,left:i*155-40,width:120,height:300+(i%4)*30,background:['#6f5b4a','#b78a58','#6f7753'][i%3],borderRadius:'12px 12px 0 0',opacity:.72}}/>)}
    <div style={{position:'absolute',bottom:0,height:330,width:'100%',background:'linear-gradient(180deg,#a37b4c,#73533b)'}}/>
    <div style={{position:'absolute',top:100,left:60,right:60,color:'#fff',textAlign:'center',fontSize:44,fontWeight:900,textShadow:'0 4px 8px #0008'}}>{episode.location}</div>
    <Rat kind="tolu" frame={frame} x={32 + Math.sin(frame/22)*5}/>
    <Rat kind="wale" frame={frame+14} x={70 + Math.cos(frame/19)*5}/>
    <div style={{position:'absolute',top:310,left:45,right:45,padding:28,background:'#1d211dcc',borderRadius:28,color:'white',opacity:titleOpacity,transform:`translateY(${(1-slide)*20}px)`}}>
      <div style={{fontSize:24,letterSpacing:4,color:'#ffd78b',fontWeight:900}}>OYO RATS CAMPAIGN • {episode.id.toUpperCase()}</div>
      <div style={{fontSize:49,lineHeight:1.1,fontWeight:900,marginTop:16}}>{episode.title}</div>
    </div>
    <Sequence from={0} durationInFrames={durationInFrames}>
      <div style={{position:'absolute',left:42,right:42,bottom:95,background:'#090909dc',padding:'22px 26px',borderRadius:20,color:'white',textAlign:'center',opacity:fade}}>
        <div style={{fontSize:28,fontWeight:800,color:'#ffd68a',marginBottom:8}}>{dialogue[0]}</div>
        <div style={{fontSize:25,lineHeight:1.2}}>{dialogue[1]}</div>
      </div>
    </Sequence>
    <div style={{position:'absolute',top:42,left:42,fontSize:23,fontWeight:900,color:'white',textShadow:'0 3px 6px #000'}}>OYỌ̀ • IBADAN</div>
    <div style={{position:'absolute',bottom:28,left:0,right:0,textAlign:'center',fontSize:34,fontWeight:1000,letterSpacing:2,color:'#fff4c7',textShadow:'0 3px 8px #000'}}>CONTINUITY. PEACE. PROGRESS.</div>
    <div style={{position:'absolute',top:42,right:42,fontSize:22,color:'white',fontWeight:700}}>{Math.floor(frame/fps/60)}:{String(Math.floor(frame/fps)%60).padStart(2,'0')}</div>
  </AbsoluteFill>;
};
