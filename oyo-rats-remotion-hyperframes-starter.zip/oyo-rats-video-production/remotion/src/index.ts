import {registerRoot} from 'remotion';
import {OyoRatsRoot} from './Root';
registerRoot(OyoRatsRoot);
