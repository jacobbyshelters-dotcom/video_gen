import episodeData from '../../scripts/episodes.json';
export type Beat = [string, string];
export type Dialogue = [string, string];
export type Episode = {
  id: string; title: string; location: string; beats: Beat[]; yoruba: Dialogue[];
};
export const episodes = episodeData as Episode[];
