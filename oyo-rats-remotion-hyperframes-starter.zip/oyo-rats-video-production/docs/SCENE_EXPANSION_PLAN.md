# 12-episode expansion plan

Each episode is 120 seconds, split into six dramatic beats of roughly 20 seconds each. Use a 24 fps timeline (2,880 frames per episode). Add more shots and performance beats within each section rather than holding a single shot for 20 seconds. Keep dialogue natural, with pauses for comedy, reaction shots, physical business, and clear subtitle timing.

## 01. The Gong That Woke the Market
- Location: A lively Ibadan market at golden hour
  - Beat 1: Cold open — Tolu is asleep inside a basket; the town crier strikes the gong and Tolu springs straight up.
  - Beat 2: Comic chase — Wale dashes between tomato baskets while Tolu tries to look dignified and trips over a yam.
  - Beat 3: The announcement — The town crier calls neighbours together to discuss peace, plans and community progress.
  - Beat 4: The argument — Tolu and Wale comically argue about promises, then realise they should listen before choosing.
  - Beat 5: The community test — They ask what a plan will actually do for roads, trade, safety and young people.
  - Beat 6: Payoff — The rats lead a cheerful market chant: Continuity. Peace. Progress.
## 02. The Great Promise Parade
- Location: A colourful Ibadan roadside parade
  - Beat 1: Cold open — Wale unfurls a banner so long it wraps around Tolu like a burrito.
  - Beat 2: Comic scramble — They chase the rolling banner through a busy but friendly street.
  - Beat 3: Promise pile-up — The rats hear a string of big promises and try to stack them into a wobbling tower.
  - Beat 4: Reality check — The tower falls; they ask for clear steps, timelines and responsibility.
  - Beat 5: Neighbour voices — Traders and young people share what they need from community leaders.
  - Beat 6: Payoff — The rats replace the giant banner with three clear words: peace, progress, continuity.
## 03. The Missing Road Map
- Location: A dusty Ibadan street with shops and okadas in the distance
  - Beat 1: Cold open — Tolu unfolds a map that turns out to be a menu; Wale points at the jollof section.
  - Beat 2: Wrong turn — They follow the map in circles, bouncing past the same kiosk three times.
  - Beat 3: Find the plan — A neighbour shows them how to look for practical road and transport commitments.
  - Beat 4: Ask questions — They ask how repairs will be prioritised and maintained.
  - Beat 5: Small win — The rats mark a clear route on a proper map and help an elderly trader cross.
  - Beat 6: Payoff — A smooth tracking shot ends on the campaign slogan.
## 04. Market Day Mix-Up
- Location: A bustling Nigerian market with fabric stalls and produce
  - Beat 1: Cold open — Wale mistakes a huge basket of peppers for a campaign hat and wears it.
  - Beat 2: Comic sneeze — Tolu's exaggerated sneeze sends lightweight flyers fluttering like butterflies.
  - Beat 3: Trader voices — Market sellers explain the importance of safe trading spaces and reliable access.
  - Beat 4: The checklist — The rats compare claims with practical market needs.
  - Beat 5: Teamwork — They help gather the flyers and organise a clean walkway.
  - Beat 6: Payoff — The market joins a joyful slogan chant.
## 05. The Gong and the Rumour
- Location: A community square near a traditional Ibadan-style street
  - Beat 1: Cold open — A rumour flies through the crowd as a paper bird; Tolu tries to catch it with a net.
  - Beat 2: Confusion — Wale repeats the rumour in a whisper that grows comically louder.
  - Beat 3: Town crier — The town crier rings the gong and asks everyone to verify information.
  - Beat 4: Check the facts — The rats look for reliable sources and compare the actual plan.
  - Beat 5: Reset — The paper bird lands; the crowd calmly discusses issues.
  - Beat 6: Payoff — The town crier leads a peaceful community chant.
## 06. The Peaceful Debate
- Location: An open-air neighbourhood meeting under shade trees
  - Beat 1: Cold open — Tolu and Wale arrive wearing oversized referee whistles.
  - Beat 2: Comic interruption — They keep blowing the whistles at the wrong moments, then hide them.
  - Beat 3: Respectful debate — Neighbours take turns describing different priorities.
  - Beat 4: Listen and compare — The rats write down points instead of shouting over one another.
  - Beat 5: Handshake — A tense disagreement ends with a friendly handshake and shared laughter.
  - Beat 6: Payoff — A wide community shot carries the peace message.
## 07. Young People, Big Ideas
- Location: A lively community youth hub in Ibadan
  - Beat 1: Cold open — Wale tries a dramatic superhero landing and bounces into a pile of soft cushions.
  - Beat 2: Idea storm — Young people pitch ideas; colourful paper notes fill the wall.
  - Beat 3: Tolu's invention — Tolu builds a comically overcomplicated idea machine that prints one simple checklist.
  - Beat 4: Opportunity talk — The group discusses skills, jobs, enterprise and access to opportunity.
  - Beat 5: Action board — They organise ideas into achievable steps and measures.
  - Beat 6: Payoff — The rats celebrate with an energetic dance.
## 08. The Clean Street Challenge
- Location: A neighbourhood street with kiosks and a drainage channel
  - Beat 1: Cold open — Tolu puts on a tiny hard hat backwards; Wale salutes a broom.
  - Beat 2: Messy mission — A gust of wind scatters paper; the rats chase it with cartoon speed.
  - Beat 3: Community care — Neighbours discuss sanitation, drainage and shared responsibility.
  - Beat 4: Plan before action — The rats identify what needs regular maintenance and who can help.
  - Beat 5: Clean-up montage — A lively montage shows sweeping, sorting and clearing a path.
  - Beat 6: Payoff — The street looks brighter and the rats strike a proud pose.
## 09. The Giant Scoreboard
- Location: A community hall with a handmade public notice board
  - Beat 1: Cold open — Wale unveils a scoreboard with so many columns it rolls across the floor.
  - Beat 2: Comic counting — Tolu uses an abacus; the beads bounce everywhere.
  - Beat 3: What to measure — The community chooses clear, fair measures for promises and delivery.
  - Beat 4: Show the evidence — The rats distinguish verified progress from rumours and guesses.
  - Beat 5: Public review — Neighbours check the board together and ask follow-up questions.
  - Beat 6: Payoff — A clean scoreboard displays practical goals and the campaign slogan.
## 10. The Neighbourhood Helpers
- Location: A residential street with shops and neighbours greeting
  - Beat 1: Cold open — Tolu wears a helper sash so long it drags behind him like a parade ribbon.
  - Beat 2: Wrong deliveries — Wale delivers a basket of oranges to the wrong door, then apologises with a bow.
  - Beat 3: Community needs — Neighbours mention safe streets, access, dependable services and cooperation.
  - Beat 4: Make a simple plan — The rats sort tasks by urgency and shared benefit.
  - Beat 5: Help in action — They assist a shopkeeper and guide children across a quiet street.
  - Beat 6: Payoff — The neighbourhood gathers for a hopeful group shot.
## 11. Tolu and Wale's Final Questions
- Location: A lively town-square discussion with stalls in the background
  - Beat 1: Cold open — Tolu pulls out a comically long scroll of questions; Wale brings a tiny pencil.
  - Beat 2: Question relay — They take turns asking practical questions and bouncing the microphone between them.
  - Beat 3: Compare the options — They consider plans, evidence, costs, timing and who benefits.
  - Beat 4: Think independently — The rats remind the crowd to make informed choices without intimidation.
  - Beat 5: Calm decision — The crowd nods, talks respectfully and reviews the information.
  - Beat 6: Payoff — The two rats look to camera and deliver the campaign message.
## 12. Continuity, Peace, Progress
- Location: Golden-hour Ibadan skyline-inspired community street celebration
  - Beat 1: Opening reprise — The gong rings; Tolu and Wale leap into frame with exaggerated synchronized moves.
  - Beat 2: Journey montage — Quick visual callbacks revisit the market, road, youth hub and community square.
  - Beat 3: Town crier's message — The town crier calls for peace, careful listening and practical plans.
  - Beat 4: Tolu's lesson — Tolu admits that loud promises alone are not enough; Wale gives an oversized nod.
  - Beat 5: Community celebration — Neighbours, traders and young people celebrate together peacefully.
  - Beat 6: Final slogan — The rats dance; the slogan fills the screen and holds for the final seconds.