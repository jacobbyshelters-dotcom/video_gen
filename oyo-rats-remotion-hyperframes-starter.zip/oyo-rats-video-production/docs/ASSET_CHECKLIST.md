# Asset checklist before final publishing

For each of the 12 episodes:
- [ ] 6–10 generated video clips, 9:16, consistent Tolu/Wale reference design
- [ ] Separate Yoruba narration WAV, reviewed by a fluent speaker
- [ ] English subtitle cues with timestamps, exported as SRT or burned in
- [ ] Licensed/royalty-free music bed
- [ ] Gong, footsteps, market ambience, comic impacts and crowd reactions
- [ ] Any location/landmark depiction checked for accuracy
- [ ] Character continuity check (Tolu green cap; Wale red bandana; both left-wrist gold watches)
- [ ] Final MP4 watched end-to-end and checked with ffprobe
- [ ] Campaign claims and any political references fact-checked before release

Do not use music, images, or voices without permission. Do not imply endorsement by real people without consent.
