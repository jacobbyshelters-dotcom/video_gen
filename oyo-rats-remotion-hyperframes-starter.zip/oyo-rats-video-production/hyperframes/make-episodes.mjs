import fs from 'node:fs/promises';
import episodes from '../scripts/episodes.json' with { type: 'json' };
const source = await fs.readFile(new URL('./index.html', import.meta.url), 'utf8');
for (const [i, ep] of episodes.entries()) {
  const title = `${String(i+1).padStart(2,'0')}. ${ep.title}`;
  const pair = ep.yoruba[0] ?? ['Ẹ gbọ́ ètò.','Listen to the plan.'];
  const html = source
    .replace('OYO RATS CAMPAIGN</div>', `${title}</div>`)
    .replace('Ẹ gbọ́ ètò, ẹ béèrè ìbéèrè.', pair[0])
    .replace('Listen to the plans and ask questions.', pair[1])
    .replace('oyo-rats-episode', ep.id);
  await fs.writeFile(new URL(`./episodes/${ep.id}.html`, import.meta.url), html);
}
console.log('Created 12 Hyperframes HTML episode drafts.');
